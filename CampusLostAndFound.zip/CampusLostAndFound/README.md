# Campus Lost and Found App

A Kotlin + XML Android Studio project for the Kabarak University Android Mobile Programming group assignment.

## Features included
- Home screen with Report Lost Item, Report Found Item and View Items buttons.
- Report form: item name, description, location, incident date, contact and category.
- Confirmation dialog and feedback after submission.
- View all reported items.
- Search items by name.
- Filter by category and Lost / Found / Claimed / Returned status.
- Tap an item to view its full details and contact information.
- Optional challenge: mark a lost item as Claimed or a found item as Returned.
- Local persistence using Android SharedPreferences (JSON), so reports remain after closing the app.

## Requirements
- Android Studio (current stable version)
- Android SDK 35
- JDK 17

## Open and run
1. Download and extract `CampusLostAndFound.zip`.
2. Open Android Studio.
3. Select **Open** and choose the extracted `CampusLostAndFound` folder (the folder containing `settings.gradle.kts`).
4. Allow Gradle sync to complete. Android Studio may download the Android Gradle Plugin and SDK components.
5. Create or start an Android emulator, or connect an Android phone with USB debugging enabled.
6. Press **Run**.

## Notes
- Package name: `com.example.campuslostfound`
- The app uses native Android Activities, TextView, EditText, Button, Spinner, ListView, Intent, AlertDialog and local storage.
- `ListView` is used as the assignment permits either RecyclerView or ListView.
- Contact details are displayed to app users. Use test data during demonstrations and do not enter private contact details without permission.
- This is a basic class-project implementation; it does not include user accounts, cloud sync or a server database.
