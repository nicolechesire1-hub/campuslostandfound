package com.example.campuslostfound

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

object ItemRepository {
    private const val PREFS = "campus_lost_found"
    private const val KEY_ITEMS = "items"

    fun getItems(context: Context): MutableList<Item> {
        val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(KEY_ITEMS, "[]") ?: "[]"
        val result = mutableListOf<Item>()
        try {
            val array = JSONArray(raw)
            for (i in 0 until array.length()) {
                val obj = array.getJSONObject(i)
                result.add(Item(
                    id = obj.optLong("id"),
                    name = obj.optString("name"),
                    description = obj.optString("description"),
                    location = obj.optString("location"),
                    date = obj.optString("date"),
                    contact = obj.optString("contact"),
                    category = obj.optString("category"),
                    status = obj.optString("status"),
                    resolved = obj.optBoolean("resolved", false)
                ))
            }
        } catch (_: Exception) { }
        return result
    }

    fun addItem(context: Context, item: Item) {
        val items = getItems(context)
        items.add(0, item)
        save(context, items)
    }

    fun markResolved(context: Context, id: Long) {
        val items = getItems(context)
        items.find { it.id == id }?.resolved = true
        save(context, items)
    }

    private fun save(context: Context, items: List<Item>) {
        val array = JSONArray()
        items.forEach { item ->
            array.put(JSONObject().apply {
                put("id", item.id)
                put("name", item.name)
                put("description", item.description)
                put("location", item.location)
                put("date", item.date)
                put("contact", item.contact)
                put("category", item.category)
                put("status", item.status)
                put("resolved", item.resolved)
            })
        }
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putString(KEY_ITEMS, array.toString()).apply()
    }
}
