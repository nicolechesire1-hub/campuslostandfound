package com.example.campuslostfound

data class Item(
    val id: Long,
    val name: String,
    val description: String,
    val location: String,
    val date: String,
    val contact: String,
    val category: String,
    val status: String,
    var resolved: Boolean = false
)
