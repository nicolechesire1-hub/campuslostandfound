package com.example.campuslostfound

import android.app.Activity
import android.app.AlertDialog
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast

class ReportActivity : Activity() {
    private lateinit var status: String

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_report)

        status = intent.getStringExtra("status") ?: "Lost"
        findViewById<TextView>(R.id.txtReportTitle).text = "Report $status Item"

        val categorySpinner = findViewById<Spinner>(R.id.spCategory)
        val categories = listOf("Electronics", "Documents", "Bags", "Clothing", "Accessories", "Other")
        categorySpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, categories)

        findViewById<Button>(R.id.btnSubmit).setOnClickListener { submitReport(categorySpinner.selectedItem.toString()) }
        findViewById<Button>(R.id.btnCancel).setOnClickListener { finish() }
    }

    private fun submitReport(category: String) {
        val name = findViewById<EditText>(R.id.etName).text.toString().trim()
        val description = findViewById<EditText>(R.id.etDescription).text.toString().trim()
        val location = findViewById<EditText>(R.id.etLocation).text.toString().trim()
        val date = findViewById<EditText>(R.id.etDate).text.toString().trim()
        val contact = findViewById<EditText>(R.id.etContact).text.toString().trim()

        if (name.isEmpty() || description.isEmpty() || location.isEmpty() || date.isEmpty() || contact.isEmpty()) {
            Toast.makeText(this, "Please complete all required fields.", Toast.LENGTH_LONG).show()
            return
        }

        AlertDialog.Builder(this)
            .setTitle("Confirm report")
            .setMessage("Submit this as a $status item report?")
            .setNegativeButton("Review", null)
            .setPositiveButton("Submit") { _, _ ->
                val item = Item(
                    id = System.currentTimeMillis(),
                    name = name,
                    description = description,
                    location = location,
                    date = date,
                    contact = contact,
                    category = category,
                    status = status
                )
                ItemRepository.addItem(this, item)
                Toast.makeText(this, "Your $status item report has been saved.", Toast.LENGTH_LONG).show()
                finish()
            }
            .show()
    }
}
