package com.example.campuslostfound

import android.view.View
import android.widget.AdapterView

class SimpleSelectionListener(private val selected: () -> Unit) : AdapterView.OnItemSelectedListener {
    override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) { selected() }
    override fun onNothingSelected(parent: AdapterView<*>?) {}
}
