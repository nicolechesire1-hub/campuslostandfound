package com.example.campuslostfound

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.widget.Button

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        findViewById<Button>(R.id.btnLost).setOnClickListener {
            openReport("Lost")
        }
        findViewById<Button>(R.id.btnFound).setOnClickListener {
            openReport("Found")
        }
        findViewById<Button>(R.id.btnView).setOnClickListener {
            startActivity(Intent(this, ItemsActivity::class.java))
        }
    }

    private fun openReport(status: String) {
        startActivity(Intent(this, ReportActivity::class.java).putExtra("status", status))
    }
}
