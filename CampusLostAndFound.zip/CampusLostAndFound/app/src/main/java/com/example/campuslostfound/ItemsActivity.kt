package com.example.campuslostfound

import android.app.Activity
import android.app.AlertDialog
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.ListView
import android.widget.Spinner
import android.widget.TextView

class ItemsActivity : Activity() {
    private lateinit var listView: ListView
    private lateinit var search: EditText
    private lateinit var categoryFilter: Spinner
    private lateinit var statusFilter: Spinner
    private lateinit var count: TextView
    private var visibleItems: List<Item> = emptyList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_items)

        listView = findViewById(R.id.listItems)
        search = findViewById(R.id.etSearch)
        categoryFilter = findViewById(R.id.spFilterCategory)
        statusFilter = findViewById(R.id.spFilterStatus)
        count = findViewById(R.id.txtCount)

        val categories = listOf("All categories", "Electronics", "Documents", "Bags", "Clothing", "Accessories", "Other")
        val statuses = listOf("All statuses", "Lost", "Found", "Claimed / Returned")
        categoryFilter.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, categories)
        statusFilter.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, statuses)

        search.addTextChangedListener(SimpleTextWatcher { refreshList() })
        categoryFilter.onItemSelectedListener = SimpleSelectionListener { refreshList() }
        statusFilter.onItemSelectedListener = SimpleSelectionListener { refreshList() }

        listView.setOnItemClickListener { _, _, position, _ ->
            showItemDetails(visibleItems[position])
        }
        findViewById<Button>(R.id.btnBack).setOnClickListener { finish() }
    }

    override fun onResume() {
        super.onResume()
        if (::listView.isInitialized) refreshList()
    }

    private fun refreshList() {
        val query = search.text.toString().trim()
        val category = categoryFilter.selectedItem?.toString() ?: "All categories"
        val status = statusFilter.selectedItem?.toString() ?: "All statuses"

        visibleItems = ItemRepository.getItems(this).filter { item ->
            val matchesName = item.name.contains(query, ignoreCase = true)
            val matchesCategory = category == "All categories" || item.category == category
            val matchesStatus = when (status) {
                "Lost" -> item.status == "Lost" && !item.resolved
                "Found" -> item.status == "Found" && !item.resolved
                "Claimed / Returned" -> item.resolved
                else -> true
            }
            matchesName && matchesCategory && matchesStatus
        }

        val rows = visibleItems.map { item ->
            val state = if (item.resolved) "CLAIMED / RETURNED" else item.status.uppercase()
            "${item.name}\n$state  •  ${item.category}\n${item.location}  |  ${item.date}"
        }
        listView.adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, rows)
        count.text = "${visibleItems.size} item(s) found  •  Tap an item for details"
    }

    private fun showItemDetails(item: Item) {
        val message = """
            Status: ${item.status}
            Category: ${item.category}
            Description: ${item.description}
            Location: ${item.location}
            Date: ${item.date}
            Contact: ${item.contact}
            ${if (item.resolved) "State: Claimed / Returned" else "State: Still active"}
        """.trimIndent()

        val builder = AlertDialog.Builder(this)
            .setTitle(item.name)
            .setMessage(message)
            .setPositiveButton("Close", null)

        if (!item.resolved) {
            builder.setNeutralButton(if (item.status == "Lost") "Mark Claimed" else "Mark Returned") { _, _ ->
                AlertDialog.Builder(this)
                    .setTitle("Confirm")
                    .setMessage("Mark this item as claimed or returned?")
                    .setNegativeButton("Cancel", null)
                    .setPositiveButton("Yes") { _, _ ->
                        ItemRepository.markResolved(this, item.id)
                        refreshList()
                    }
                    .show()
            }
        }
        builder.show()
    }
}
